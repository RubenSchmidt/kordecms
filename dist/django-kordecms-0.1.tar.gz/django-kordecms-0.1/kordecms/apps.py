from django.apps import AppConfig


class KordeCmsConfig(AppConfig):
    name = 'kordecms'
